document.addEventListener('DOMContentLoaded', function() {
    var copyButton = document.getElementById('copyButton');
    var copyTextBox = document.getElementById('copyTextBox');
  
    copyButton.addEventListener('click', function() {
      var websiteUrls = [];
      var inputText = copyTextBox.value.split('\n'); // Split input text by newline character
  
      // Process each line of input text
      inputText.forEach(function(websiteUrl) {
        websiteUrl = websiteUrl.trim(); // Trim leading and trailing whitespace
        if (websiteUrl === '' || websiteUrl.includes('facebook.com') || websiteUrl.includes('trustpilot.com') || websiteUrl.includes('google.com') || websiteUrl.includes('wix.com')) {
          websiteUrls.push(""); // Push empty string for invalid URLs or empty lines
        } else {
          var parsedUrl = new URL(websiteUrl);
          websiteUrls.push(parsedUrl.origin + "/"); // Extract main URL without page-specific part
        }
      });
  
      // Copy the website URLs in the same order as they appear in the textbox
      if (websiteUrls.length > 0) {
        var websitesString = '"' + websiteUrls.join('","') + '"';
        navigator.clipboard.writeText(websitesString)
          .then(function() {
            console.log('Websites copied to clipboard:', websitesString);
            alert('Websites copied to clipboard!');
          })
          .catch(function(error) {
            console.error('Error copying to clipboard:', error);
            alert('Error copying to clipboard. Please try again.');
          });
      } else {
        alert('No valid websites found to copy.');
      }
    });
  });
  