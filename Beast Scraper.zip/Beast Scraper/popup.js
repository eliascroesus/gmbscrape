document.addEventListener('DOMContentLoaded', function() {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        var currentTab = tabs[0];
        var actionButton = document.getElementById('actionButton');
        var downloadCsvButton = document.getElementById('downloadCsvButton');
        var copyToClipboardButton = document.getElementById('copyToClipboardButton'); // New button
        var resultsTable = document.getElementById('resultsTable');
        var filenameInput = document.getElementById('filenameInput');

        if (currentTab && currentTab.url.includes("://www.google.com/maps/search")) {
            document.getElementById('message').textContent = "Let's scrape Google Maps!";
            actionButton.disabled = false;
            actionButton.classList.add('enabled');
        } else {
            var messageElement = document.getElementById('message');
            messageElement.innerHTML = '';
            var linkElement = document.createElement('a');
            linkElement.href = 'https://www.google.com/maps/search/';
            linkElement.textContent = "Go to Google Maps Search.";
            linkElement.target = '_blank'; 
            messageElement.appendChild(linkElement);

            actionButton.style.display = 'none'; 
            downloadCsvButton.style.display = 'none';
            copyToClipboardButton.style.display = 'none'; // Hide the button if not on Google Maps
            filenameInput.style.display = 'none'; 
        }

        actionButton.addEventListener('click', function() {
            chrome.scripting.executeScript({
                target: { tabId: currentTab.id },
                function: scrapeData
            }, function(results) {
                while (resultsTable.firstChild) {
                    resultsTable.removeChild(resultsTable.firstChild);
                }

                // Define and add headers to the table
                const headers = ['Title', 'Rating', 'Reviews', 'Phone', 'Category', 'Industry', 'Email', 'Open', 'Facebook', 'Website', 'Google Maps Link'];
                const headerRow = document.createElement('tr');
                headers.forEach(headerText => {
                    const header = document.createElement('th');
                    header.textContent = headerText;
                    headerRow.appendChild(header);
                });
                resultsTable.appendChild(headerRow);

                // Add new results to the table
                if (!results || !results[0] || !results[0].result) return;
                results[0].result.forEach(function(item) {
                    var row = document.createElement('tr');
                    ['title', 'rating', 'reviewCount', 'phone', 'category', 'industry', 'email','open', 'facebookUrl', 'companyUrl', 'href'].forEach(function(key) {
                        var cell = document.createElement('td');
                        if (key === 'reviewCount' && item[key]) {
                            item[key] = item[key].replace(/\(|\)/g, '');
                        }
                        cell.textContent = item[key] || ' '; // Replace empty strings with space
                        row.appendChild(cell);
                    });
                    resultsTable.appendChild(row);
                });

                if (results && results[0] && results[0].result && results[0].result.length > 0) {
                    downloadCsvButton.disabled = false;
                    copyToClipboardButton.disabled = false; // Enable the button when data is available
                }
            });
        });

        downloadCsvButton.addEventListener('click', function() {
            var csv = tableToCsv(resultsTable, ','); // Use comma for CSV file
            var filename = filenameInput.value.trim();
            if (!filename) {
                filename = 'google-maps-data.csv';
            } else {
                filename = filename.replace(/[^a-z0-9]/gi, '_').toLowerCase() + '.csv';
            }
            downloadCsv(csv, filename);
        });

        copyToClipboardButton.addEventListener('click', function() { // Add event listener for the new button
            var tsv = tableToCsv(resultsTable, '\t'); // Use tab for clipboard
            copyToClipboard(tsv);
        });
    });
});

function scrapeData() {
    var links = Array.from(document.querySelectorAll('a[href^="https://www.google.com/maps/place"]'));
    return links.map(link => {
        var container = link.closest('[jsaction*="mouseover:pane"]');
        var titleText = container ? container.querySelector('.fontHeadlineSmall').textContent : '';
        var rating = '';
        var reviewCount = '';
        var phone = '';
        var industry = '';
        var companyUrl = '';
        var email = '';
        var open = '';
        var facebookUrl = '';

        // Rating and Reviews
        if (container) {
            var roleImgContainer = container.querySelector('[role="img"]');
            if (roleImgContainer) {
                var ariaLabel = roleImgContainer.getAttribute('aria-label');
                if (ariaLabel && ariaLabel.includes("stars")) {
                    var parts = ariaLabel.split(' ');
                    var rating = parts[0];
                    var reviewCount = '(' + parts[2] + ')';
                } else {
                    rating = '0';
                    reviewCount = '0';
                }
            }
        }

        // Company URL
        if (container) {
            var websiteElement = container.querySelector('.scrapio-icon-detail[data-type="website"]');
            if (websiteElement) {
                companyUrl = websiteElement.getAttribute('data-url');
            }
        }

        // Phone Numbers
        if (container) {
            var telElement = container.querySelector('.scrapio-icon-detail[data-type="phone_international"]');
            if (telElement) {
                phone = telElement.getAttribute('data-url').replace('tel:', '');
            }
        }

        // Email
        if (container) {
            var emailElement = container.querySelector('.scrapio-icon-detail[data-type="emails"]');
            if (emailElement) {
                email = emailElement.getAttribute('data-url').replace('mailto:', '');
            }
        }
        
        // Facebook
        if (container) {
            var facebookElement = container.querySelector('.scrapio-icon-detail[data-type="facebook"]');
            if (facebookElement) {
                facebookUrl = facebookElement.getAttribute('data-url');
            }
        }

        // Category
        if (container) {
            var categoryElements = Array.from(container.querySelectorAll('div.W4Efsd'));
            var categoryElement = categoryElements.find(el => el.querySelector('span > span') && !el.querySelector('div[role="img"]') && !el.querySelector('.AJB7ye'));
            if (categoryElement) {
                var categorySpan = categoryElement.querySelector('span > span');
                if (categorySpan) {
                    var companyCategory = categorySpan.innerText.trim();
                }
            }
        }

        //Open
        if (container) {
            var addressElements = Array.from(container.querySelectorAll('div.W4Efsd'));
            var addressElement = addressElements.find(el => el.querySelector('span > span') && !el.querySelector('div[role="img"]') && !el.querySelector('.AJB7ye'));
            if (addressElement) {
                var addressSpan = addressElement.querySelectorAll('span > span');
                if (addressSpan.length > 1) {
                    var open = addressSpan[addressSpan.length - 1].innerText.trim();
                }
            }
        }

        // Return the data as an object
        return {
            title: titleText,
            rating: rating,
            reviewCount: reviewCount,
            phone: phone,
            industry: industry,
            companyUrl: companyUrl,
            href: link.href,
            email: email,  // Add email to the returned object
            facebookUrl: facebookUrl,
            category: companyCategory,
            open: open
        };
    });
}

// Convert the table to a CSV string
function tableToCsv(table, delimiter) {
    var csv = [];
    var rows = table.querySelectorAll('tr');
    
    for (var i = 0; i < rows.length; i++) {
        var row = [], cols = rows[i].querySelectorAll('td, th');
        
        for (var j = 0; j < cols.length; j++) {
            var cellText = cols[j].innerText.replace(/"/g, '""'); // Escape double quotes
            row.push(cellText); // Push the cell content directly
        }
        csv.push(row.join(delimiter)); // Join columns with the delimiter
    }
    return csv.join('\n'); // Join rows with a new line
}

// Copy the CSV data to the clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        alert('Data copied to clipboard');
    }, function(err) {
        console.error('Could not copy text: ', err);
    });
}

// Download the CSV file
function downloadCsv(csv, filename) {
    var csvFile;
    var downloadLink;

    csvFile = new Blob([csv], { type: 'text/csv' });
    downloadLink = document.createElement('a');
    downloadLink.download = filename;
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.style.display = 'none';
    document.body.appendChild(downloadLink);
    downloadLink.click();
}
