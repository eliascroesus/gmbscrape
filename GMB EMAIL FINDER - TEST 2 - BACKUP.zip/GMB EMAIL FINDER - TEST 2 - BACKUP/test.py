import os
import pandas as pd
import re
import scrapy
from scrapy.crawler import CrawlerProcess
from scrapy.linkextractors.lxmlhtml import LxmlLinkExtractor
import random
from urllib.parse import urlparse

class MailSpider(scrapy.Spider):
    name = 'email'

    custom_settings = {
        'USER_AGENT': 'Mozilla/5.0',
        'CONCURRENT_REQUESTS': 20,  # Increase concurrent requests
        'DOWNLOAD_TIMEOUT': 15,  # Set a timeout for requests
    }

    def __init__(self, *args, **kwargs):
        super(MailSpider, self).__init__(*args, **kwargs)
        self.reject = kwargs.get('reject', [])
        self.reject_domains = kwargs.get('reject_domains', [])
        self.reject_emails = kwargs.get('reject_emails', [])
        self.regex_pattern = kwargs.get('regex_pattern', r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
        self.email_data = {}  # Dictionary to store emails grouped by website URL

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, callback=self.parse, headers={'User-Agent': self.get_random_user_agent()}, dont_filter=True, meta={'dont_retry': True})

    def parse(self, response):
        links = LxmlLinkExtractor(allow=()).extract_links(response)
        links = [str(link.url) for link in links]
        links.append(str(response.url))

        for link in links:
            yield scrapy.Request(url=link, callback=self.parse_link, headers={'User-Agent': self.get_random_user_agent()}, dont_filter=True, meta={'dont_retry': True, 'url': response.url})

    def parse_link(self, response):
        for word in self.reject:
            if word in str(response.url):
                return

        html_text = str(response.text)
        mail_list = re.findall(self.regex_pattern, html_text)

        domain = urlparse(response.url).netloc
        if domain not in self.email_data:
            self.email_data[domain] = {'emails': set(), 'urls': set()}

        self.email_data[domain]['urls'].add(response.meta['url'])

        for email in mail_list:
            email_lower = email.lower()  # Convert email to lowercase
            if email_lower not in self.email_data[domain]['emails'] and not any(domain in email_lower for domain in self.reject_domains) and not any(word in email_lower for word in self.reject_emails):
                self.email_data[domain]['emails'].add(email_lower)

    def closed(self, reason):
        # Save the collected emails and URLs to CSV
        with open(self.path, 'a') as f:
            for domain, data in self.email_data.items():
                if data['emails']:  # Check if there are emails collected
                    emails_str = ','.join(data['emails'])
                    urls_str = ','.join(data['urls'])
                    f.write(f"{domain},{emails_str},{urls_str}\n")

    def get_random_user_agent(self):
        user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
            'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0',
            'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36',
            'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Safari/605.1.15',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Safari/605.1.15'
        ]
        return random.choice(user_agents)

def ask_user(question):
    response = input(question + ' y/n' + '\n')
    if response == 'y':
        return True
    else:
        return False

def create_file(path):
    response = False
    if os.path.exists(path):
        response = ask_user('File already exists, replace?')
        if response == False:
            return 

    with open(path, 'wb') as file: 
        file.close()

def get_info(url_list, path, reject=[], reject_domains=[], reject_emails=[], regex_pattern=r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'):
    create_file(path)
    df = pd.DataFrame(columns=['email', 'link', 'url'])

    df.to_csv(path, mode='w', header=True, index=False)  # Removed index column

    print('Collecting Google urls...')
    process = CrawlerProcess({'USER_AGENT': 'Mozilla/5.0'})

    for url in url_list:
        process.crawl(MailSpider, start_urls=[url], path=path, reject=reject, reject_domains=reject_domains, reject_emails=reject_emails, regex_pattern=regex_pattern)
        
    process.start()

    print('Cleaning emails...')
    df = pd.read_csv(path)
    df.columns = ['email', 'link', 'url']
    df = df.apply(lambda x: x.str.lower() if x.name == 'email' else x)  # Convert emails to lowercase
    df = df.drop_duplicates(subset='email')  # Remove duplicate emails
    df = df.reset_index(drop=True)
    df.to_csv(path, mode='w', header=True, index=False)  # Removed index column

    return df

url_list = [
    "","http://www.jacksonph.com","","","","https://www.deadriver.com"
]
path = 'email.csv'

# Specify patterns to reject
reject_patterns = ['@sentry.wixpress', '@wix', '@squarespace', '@domain', '@email', '@mail', '@sentry', '@mystunningwebsite']

# Specify regex pattern to exclude emails with numbers immediately after the "@" symbol
custom_regex_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}(?!\d)\b'

# Call get_info with reject patterns, reject emails, and custom regex pattern
df = get_info(url_list, path, reject_domains=reject_patterns, regex_pattern=custom_regex_pattern)
