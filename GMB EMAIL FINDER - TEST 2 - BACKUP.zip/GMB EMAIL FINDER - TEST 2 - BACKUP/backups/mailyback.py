from bs4 import BeautifulSoup
import requests
import requests.exceptions
import urllib.parse
from collections import deque
import re
import time
from fake_useragent import UserAgent
import random  

# Define the URL validation function
def is_valid_url(url):
    try:
        result = urllib.parse.urlsplit(url)
        return all([result.scheme, result.netloc])
    except ValueError:
        return False

# Generate a random User-Agent
def get_random_user_agent():
    ua = UserAgent()
    return ua.random

# Function to handle different HTTP status codes
def handle_response_code(response):
    status_code = response.status_code
    if status_code == 429:
        print("Rate limiting detected. Adjusting scraping behavior...")
        # Increase delay time for rate limiting
        time.sleep(10)  # Example: Increase delay to 10 seconds
    elif status_code == 503:
        print("Server error detected. Adjusting scraping behavior...")
        # Increase delay time for server errors
        time.sleep(5)  # Example: Increase delay to 5 seconds
    elif status_code >= 400:
        print(f"Error: Received status code {status_code}. Skipping URL...")

# Function to extract contact information from URLs
def extract_contact_info(url):
    email_matches = re.findall(r"mailto:([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})", url)
    tel_matches = re.findall(r"tel:(\+\d{1,3}\s)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}", url)
    return email_matches, tel_matches

# Adjusted delay time
delay_seconds = 3  

while True:  # Keep prompting until a valid URL is provided
    user_url = input('[+] Enter the URL: ')
    if is_valid_url(user_url):
        break
    else:
        print("Invalid URL. Please enter a valid URL.")

urls = deque([user_url])

scraped_urls = set()
unique_emails = set()  # Store unique emails here
unique_emails_lower = set()  # Store unique emails in lowercase
count = 0

# Add a list of proxies to rotate
proxies = [
    'http://149.20.253.107:12551',
    'http://161.97.156.209:29118',
    'http://128.199.114.221:60879',
    'http://83.168.84.141:4153',
    'http://186.225.149.81:4145',
    'http://96.9.86.218:5678',
    'http://134.209.23.68:22773',
    'http://5.161.100.145:1080',
    'http://104.21.218.103',
    'http://24.147.144.221:15280',
    'http://38.127.172.128:12697',
    'http://195.225.49.134:55774',
    'http://147.182.138.236:53846',
    'http://46.231.72.35',
    'http://198.199.122.10',
    'http://161.97.97.231',
    'http://157.185.160.74',
    'http://104.129.192.55',
    'http://164.132.162.92',
    'http://104.16.109.213',
    'http://104.22.14.48',
    'http://45.12.30.170'
]

# Define strings to filter out
filter_strings = ["sentry.io", "@sentry", ".png"]

# Email name options
email_names = [
    "info", "hello", "support", "enquiries", "admin", "contact", "sales", 
    "marketing", "webmaster", "billing", "office", "service", "help", 
    "feedback", "team", "careers", "media", "press", "legal", "privacy", 
    "terms", "policy", "newsletter", "subscribe", "unsubscribe", 
    "notification", "alerts", "update", "noreply", "donotreply", 
    "news", "blog", "forum", "helpdesk", "customer", "clients", 
    "booking", "order", "purchase", "invoice", "register", 
    "signup", "login", "account", "checkout", "shipping", 
    "returns", "refund", "payment", "feedback", "enquiry", 
    "queries", "ticket", "survey", "verification", "activation", 
    "confirmation", "reminder", "welcome", "greetings", 
    "invitation", "subscribe"
]

# Initialize session object
session = requests.Session()

try:
    while len(urls):
        count += 1
        if count == 25:
            break
        url = urls.popleft()
        scraped_urls.add(url)

        parts = urllib.parse.urlsplit(url)
        base_domain = '{0.scheme}://{0.netloc}'.format(parts)

        path = url[:url.rfind('/')+1] if '/' in parts.path else url

        print('[%d] Processing %s' % (count, url))
        try:
            # Select a random proxy from the list
            proxy = random.choice(proxies)
            response = session.get(url, proxies={'http': proxy}, headers={'User-Agent': get_random_user_agent()}, timeout=10)  # Added timeout
        except (requests.exceptions.MissingSchema, requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
            print(f"Error occurred while fetching {url}: {e}")
            continue

        # Handle response codes
        handle_response_code(response)

        # Extract contact information from the URL if it's a 404 error
        if response.status_code == 404:
            email_matches, tel_matches = extract_contact_info(url)
            unique_emails.update(email_matches)  # Add to unique_emails instead of emails
            # Add telephone numbers to a set if needed
            # You can do the same for other contact information

        new_emails = set(re.findall(r"[a-z0-9\.\-+_{}]+@[a-z0-9\.\-+_]+\.[a-z]+", response.text, re.I))
        # Add only new emails to the set after converting them to lowercase
        unique_emails_lower.update(new_email.lower() for new_email in new_emails)

        soup = BeautifulSoup(response.text, features="lxml")

        for anchor in soup.find_all("a"):
            link = anchor.attrs['href'] if 'href' in anchor.attrs else ''
            if link.startswith('/'):
                link = base_domain + link
            elif not link.startswith('http'):
                link = path + link
            if 'tripadvisor' not in link and '.comtel' not in link and '.commail' not in link and not link in urls and not link in scraped_urls and base_domain in link:  # Ensure link belongs to the same domain
                if link.startswith('http') and is_valid_url(link):  # Check if the URL starts with 'http' and is valid before adding it to the queue
                    urls.append(link)
                else:
                    print(f"Invalid URL: {link}")
except KeyboardInterrupt:
    print('[-] Closing!')

for mail in unique_emails_lower:
    if not any(filter_string in mail for filter_string in filter_strings):
        # Extract the part before '@'
        name = mail.split('@')[0]
        # Check if the name is in the list of email names
        if name.lower() in email_names:
            print("Name: None")
            print("Email:", mail)
        else:
            print("Name:", name.capitalize())
            print("Email:", mail)
