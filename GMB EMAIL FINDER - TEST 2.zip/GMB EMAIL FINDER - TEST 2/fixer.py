import csv
import re
import os

def is_email(string):
    # Simple regex pattern to check if a string contains an email address
    return re.match(r"[^@]+@[^@]+\.[^@]+", string)

def extract_main_url(url):
    # Extract main part of the URL like www.example.com
    match = re.match(r"https?://(?:www\.)?([^/]+)", url)
    if match:
        return match.group(1)
    return url

def read_csv(file_path):
    rows = []
    website_urls_emails = {}  # Dictionary to store website URLs and their corresponding emails
    with open(file_path, 'r') as file:
        csv_reader = csv.reader(file)
        for row in csv_reader:
            website_urls = []
            emails = []
            for item in row:
                if is_email(item):
                    emails.append(item.strip())  # Strip any leading/trailing whitespace
                else:
                    website_urls.append(item.strip())  # Strip any leading/trailing whitespace
            
            # If there are emails associated with website URLs, store them in a dictionary
            if website_urls and emails:
                for url in website_urls:
                    main_url = extract_main_url(url)
                    website_urls_emails[main_url] = emails
            rows.append((website_urls, emails))
    
    # Replace website URLs after "email, link, url" part with corresponding emails
    for i, (website_urls, emails) in enumerate(rows):
        for j, url in enumerate(website_urls):
            main_url = extract_main_url(url)
            if main_url in website_urls_emails:
                rows[i][0][j] = website_urls_emails[main_url]
    
    return rows

def write_csv(data, file_path, replace_existing=False):
    mode = 'a' if not replace_existing else 'w'
    with open(file_path, mode, newline='') as file:
        csv_writer = csv.writer(file)
        if replace_existing:
            file.truncate(0)  # Clear the file if replacing existing
        for website_urls, emails in data:
            # Flatten the list of website URLs if it contains nested lists
            website_urls_flat = [url for sublist in website_urls for url in sublist]
            csv_writer.writerow(website_urls_flat + emails)

def filter_non_email_rows(rows):
    filtered_rows = []
    for website_urls, emails in rows:
        # Check if any item in the row contains '@'
        if any('@' in item for sublist in website_urls for item in sublist) or emails:
            filtered_rows.append((website_urls, emails))
        else:
            filtered_rows.append(([], []))  # Append an empty row
    return filtered_rows


file_path = 'email.csv'
output_file_path = 'results.csv'

# Check if the output file already exists
if os.path.exists(output_file_path):
    replace_choice = input("File already exists. Replace? (y/n): ").lower()
    if replace_choice == 'y':
        replace_existing = True
    else:
        replace_existing = False
else:
    replace_existing = False

data = read_csv(file_path)
data_filtered = filter_non_email_rows(data)
write_csv(data_filtered, output_file_path, replace_existing=replace_existing)

print("Results have been written to results.csv")
