import csv
from urllib.parse import urlparse

# Define the file name
file_name = "email.csv"

# Initialize a dictionary to store rows grouped by website URL
rows_by_website = {}

# Initialize a list to store individual website URLs and remaining rows
individual_urls = []

# Initialize a set to store unique non-filtered emails
non_filtered_emails_set = set()

# Open the CSV file and read its contents
with open(file_name, "r", newline="") as csvfile:
    csvreader = csv.reader(csvfile)
    is_header = True
    
    # Iterate over each row in the CSV file
    for row in csvreader:
        # Skip the header row
        if is_header:
            is_header = False
            continue
        
        # Check if the row has both a website URL and at least one email
        if len(row) >= 2 and row[0].startswith("http") and any("@" in email for email in row[1:]):
            website_url = row[0]
            parsed_url = urlparse(website_url)
            main_url = parsed_url.netloc.replace("www.", "")  # Extract main part of the website URL
            
            emails = []
            for email in row[1:]:
                if "@" in email:
                    domain = email.split("@")[1]  # Extract domain part from email
                    if domain == main_url or domain.endswith(("gmail.com", "yahoo.com", "aol.com", "outlook.com", "icloud.com", "protonmail.com", "mail.com", "comcast.net", "verizon.net", "sbcglobal.net", "cox.net", "att.net", "charter.net", "msn.com", "office365.com", "googlemail.com", "yahoo.com", "zoho.com", "yahoo.co.uk", "hotmail.co.uk", "btinternet.com", "virginmedia.com", "live.co.uk", "blueyonder.co.uk", "talktalk.net", "sky.com", "tiscali.co.uk", "ntlworld.com", "lineone.net", "fsmail.net", "googlemail.com", "zoho.com")):
                        emails.append(email.strip())
                    else:
                        non_filtered_emails_set.add(email.strip())  # Store non-filtered emails
            
            # Check if website URL already exists in the dictionary
            if website_url in rows_by_website:
                # Append emails to existing list of emails for this website URL
                rows_by_website[website_url].extend(emails)
            else:
                # Create a new list of emails for this website URL
                rows_by_website[website_url] = emails
        else:
            # If it's not a website URL with emails, append to individual_urls
            individual_urls.append(row)

# Convert non-filtered emails set to a list and sort it
non_filtered_emails = sorted(list(non_filtered_emails_set))

# Write grouped rows back to the CSV file
with open(file_name, "w", newline="") as csvfile:
    csvwriter = csv.writer(csvfile)
    
    # Write grouped rows
    # Write grouped rows
    for website_url, emails in rows_by_website.items():
    # Remove duplicates from emails list
        unique_emails = list(set(emails))
    
    # Join each element of the row with a comma and a space
        row_to_write = ",  ".join([website_url] + unique_emails)
    
    # Write the row to the CSV file without quotation marks
        csvwriter.writerow(row_to_write.split(", "))

    
    # Write a blank row to separate filtered emails from non-filtered emails
    csvwriter.writerow([])
    
    # Write non-filtered emails
    for email in non_filtered_emails:
        # Write each email as a separate row
        csvwriter.writerow([email])
    
    # Write individual website URLs and remaining rows
    for row in individual_urls:
        # Write each row as it is
        csvwriter.writerow(row)
