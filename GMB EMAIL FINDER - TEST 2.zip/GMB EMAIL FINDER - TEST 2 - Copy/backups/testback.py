import os
import pandas as pd
import re
import scrapy
from scrapy.crawler import CrawlerProcess
from scrapy.linkextractors.lxmlhtml import LxmlLinkExtractor

class MailSpider(scrapy.Spider):
    name = 'email'

    def __init__(self, *args, **kwargs):
        super(MailSpider, self).__init__(*args, **kwargs)
        self.reject = kwargs.get('reject', [])
        self.reject_domains = kwargs.get('reject_domains', [])
        self.reject_emails = kwargs.get('reject_emails', [])
        self.regex_pattern = kwargs.get('regex_pattern', r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')

    def parse(self, response):
        links = LxmlLinkExtractor(allow=()).extract_links(response)
        links = [str(link.url) for link in links]
        links.append(str(response.url))

        for link in links:
            yield scrapy.Request(url=link, callback=self.parse_link)

    def parse_link(self, response):
        for word in self.reject:
            if word in str(response.url):
                return

        html_text = str(response.text)
        mail_list = re.findall(self.regex_pattern, html_text)

        filtered_emails = []
        for email in mail_list:
            email_lower = email.lower()  # Convert email to lowercase
            if email_lower not in filtered_emails and not any(domain in email_lower for domain in self.reject_domains) and not any(word in email_lower for word in self.reject_emails):
                filtered_emails.append(email_lower)

        dic = {'email': filtered_emails, 'link': str(response.url)}
        df = pd.DataFrame(dic)

        df.to_csv(self.path, mode='a', header=False)


def ask_user(question):
    response = input(question + ' y/n' + '\n')
    if response == 'y':
        return True
    else:
        return False


def create_file(path):
    response = False
    if os.path.exists(path):
        response = ask_user('File already exists, replace?')
        if response == False:
            return 

    with open(path, 'wb') as file: 
        file.close()


def get_info(url_list, path, reject=[], reject_domains=[], reject_emails=[], regex_pattern=r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'):
    create_file(path)
    df = pd.DataFrame(columns=['email', 'link'])

    df.to_csv(path, mode='w', header=True)

    print('Collecting Google urls...')
    process = CrawlerProcess({'USER_AGENT': 'Mozilla/5.0'})

    for url in url_list:
        process.crawl(MailSpider, start_urls=[url], path=path, reject=reject, reject_domains=reject_domains, reject_emails=reject_emails, regex_pattern=regex_pattern)
        
    process.start()

    print('Cleaning emails...')
    df = pd.read_csv(path, index_col=0)
    df.columns = ['email', 'link']
    df = df.apply(lambda x: x.str.lower() if x.name == 'email' else x)  # Convert emails to lowercase
    df = df.drop_duplicates(subset='email')  # Remove duplicate emails
    df = df.reset_index(drop=True)
    df.to_csv(path, mode='w', header=True)

    return df


url_list = [
    "https://pyxidafishtavern.com/",
    "https://www.forestcityplumbing.com/",
    "http://bealplumbing.com/",
    "http://www.afishplumbingandheating.net/",
    "http://www.mikesplumbingandrooterservice.com/contact-us/"
]
path = 'email.csv'

# Specify patterns to reject
reject_patterns = ['@sentry.wixpress', '@wix', '@squarespace', '@domain', '@email', '@mail', '@sentry', '@mystunningwebsite']

# Specify regex pattern to exclude emails with numbers immediately after the "@" symbol
custom_regex_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}(?!\d)\b'

# Call get_info with reject patterns, reject emails, and custom regex pattern
df = get_info(url_list, path, reject_domains=reject_patterns, regex_pattern=custom_regex_pattern)

