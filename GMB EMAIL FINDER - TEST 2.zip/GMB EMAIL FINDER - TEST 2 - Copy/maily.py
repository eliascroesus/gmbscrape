from bs4 import BeautifulSoup
import requests
import requests.exceptions
import urllib.parse
from collections import deque
import re
import time
from fake_useragent import UserAgent
import random
import csv

# Define the URL validation function
def is_valid_url(url):
    try:
        result = urllib.parse.urlsplit(url)
        return all([result.scheme, result.netloc])
    except ValueError:
        return False

# Generate a random User-Agent
def get_random_user_agent():
    ua = UserAgent()
    return ua.random

# Function to handle different HTTP status codes
def handle_response_code(response):
    status_code = response.status_code
    if status_code == 429:
        print("Rate limiting detected. Adjusting scraping behavior...")
        # Increase delay time for rate limiting
        time.sleep(10)  # Example: Increase delay to 10 seconds
    elif status_code == 503:
        print("Server error detected. Adjusting scraping behavior...")
        # Increase delay time for server errors
        time.sleep(5)  # Example: Increase delay to 5 seconds
    elif status_code >= 400:
        print(f"Error: Received status code {status_code}. Skipping URL...")

# Function to extract contact information from URLs
def extract_contact_info(url):
    email_matches = re.findall(r"mailto:([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})", url)
    tel_matches = re.findall(r"tel:(\+\d{1,3}\s)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}", url)
    return email_matches, tel_matches

# Adjusted delay time
delay_seconds = 3

# Function to scrape emails from a given URL
def scrape_emails(url):
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception for 4xx or 5xx status codes
        soup = BeautifulSoup(response.text, 'html.parser')
        emails = set(re.findall(r"[a-z0-9\.\-+_]+@[a-z0-9\.\-+_]+\.[a-z]+", soup.get_text(), re.I))
        return emails
    except (requests.exceptions.RequestException, ValueError, AttributeError):
        return set()

# Function to read CSV file and extract website URLs
def extract_website_urls(csv_file):
    website_urls = []
    with open(csv_file, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            # Check if the row has a website URL
            if row['Website']:
                website_urls.append(row['Website'])
    return website_urls

# Initialize session object
session = requests.Session()

# Read website URLs from CSV file
csv_file = 'g.csv'  # Replace 'your_file.csv' with the path to your CSV file
website_urls = extract_website_urls(csv_file)

# Initialize dictionary to store URLs by domain
domain_queues = {}

# Add website URLs to their respective domain queues
for url in website_urls:
    domain = urllib.parse.urlparse(url).netloc
    if domain not in domain_queues:
        domain_queues[domain] = deque([url])
    else:
        domain_queues[domain].append(url)

scraped_urls = set()
unique_emails = set()  # Store unique emails here
unique_emails_lower = set()  # Store unique emails in lowercase
count = 0

# Add a list of proxies to rotate
proxies = [
    'http://35.185.196.38:3128',
    'http://134.209.67.109:12764',
    'http://159.65.165.75:80',
    'http://47.251.74.226:80',
    'http://35.244.181.58:80',
    'http://34.36.175.183:80',
    'http://69.25.155.173:80',
    'http://34.120.58.14:80',
    'http://134.209.67.109:26000',
    'http://134.209.67.109:19752',
    'http://35.185.196.38:3128',
    'http://159.65.170.18:80',
    'http://34.111.135.19:80',
    'http://34.110.195.160:80',
    'http://34.36.226.184:80',
    'http://3.93.71.36:80',
    'http://34.36.183.121:80',
    # Add more proxies here if needed
]


# Set maximum scraping depth
max_depth = 5

# Define page priorities
priority_pages = ['contact', 'about', 'home', 'main', 'index']

# Initialize a set to keep track of scraped URLs
scraped_urls = set()

try:
    for domain, urls in domain_queues.items():
        while len(urls):
            count += 1
            if count == 25:
                break
            url = urls.popleft()
            
            # Check if the URL has already been scraped
            if url in scraped_urls:
                print(f"URL {url} has already been scraped. Skipping...")
                continue
            else:
                # Add the URL to the set of scraped URLs
                scraped_urls.add(url)

            print('[%d] Processing %s' % (count, url))
            try:
                # Select a random proxy from the list
                proxy = random.choice(proxies)
                response = session.get(url, proxies={'http': proxy}, headers={'User-Agent': get_random_user_agent()}, timeout=10)  # Added timeout
            except (requests.exceptions.MissingSchema, requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
                print(f"Error occurred while fetching {url}: {e}")
                continue

            # Handle response codes
            handle_response_code(response)

            # Extract emails from the current URL
            emails = scrape_emails(url)
            unique_emails.update(emails)
            unique_emails_lower.update(email.lower() for email in emails)

            # Update scraping depth for the next URLs
            depth = url.count('/') - 2  # Depth calculation assuming domain.com/ is depth 0
            if depth < max_depth:
                soup = BeautifulSoup(response.text, features="lxml")
                for anchor in soup.find_all("a"):
                    link = anchor.attrs.get('href', '')
                    if link.startswith('/'):
                        link = urllib.parse.urljoin(url, link)
                    elif not link.startswith('http'):
                        link = urllib.parse.urljoin(url, link)
                    if not any(prio_page in link.lower() for prio_page in priority_pages):
                        if is_valid_url(link) and urllib.parse.urlparse(link).netloc == domain:  # Check if the URL is valid and belongs to the same domain
                            urls.append(link)
                    else:
                        if is_valid_url(link) and urllib.parse.urlparse(link).netloc == domain:  # Check if the URL is valid and belongs to the same domain
                            urls.appendleft(link)
            else:
                print("Maximum depth reached for this domain.")

except KeyboardInterrupt:
    print('[-] Closing!')

# Print the scraped emails
for email in unique_emails_lower:
    print(email)
